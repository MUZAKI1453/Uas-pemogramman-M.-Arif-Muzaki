package org.arief.demoujicoba.service;

import org.arief.demoujicoba.domain.Pemasukan;
import org.springframework.data.domain.Page;

public interface PemasukanService {

    Pemasukan createPemasukan(Pemasukan pemasukan);

    Page<Pemasukan> getPemasukan(int page, int size);

    void updatePemasukan(Pemasukan pemasukan);

    Pemasukan getPemasukanByKeterangan(String keterangan);

    void deletePemasukan(String keterangan);
}
