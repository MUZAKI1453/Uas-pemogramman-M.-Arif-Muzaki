package org.arief.demoujicoba.controller;

import lombok.AllArgsConstructor;
import org.arief.demoujicoba.domain.HttpResponse;
import org.arief.demoujicoba.domain.Pemasukan;
import org.arief.demoujicoba.service.PemasukanService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/pemasukan")
@AllArgsConstructor
public class PemasukanController {

    private final PemasukanService pemasukanService;

    @PostMapping("create")
    public ResponseEntity<HttpResponse> createPemasukan(@RequestBody Pemasukan pemasukan) {
        return ResponseEntity.created(URI.create(""))
                .body(
                        HttpResponse.builder()
                                .timeStamp(LocalDateTime.now().toString())
                                .data(Map.of("pemasukan", pemasukanService.createPemasukan(pemasukan)))
                                .message("Pemasukan created")
                                .status(HttpStatus.CREATED)
                                .statusCode(HttpStatus.CREATED.value())
                                .build()
                );
    }

    @GetMapping("list")
    public ResponseEntity<HttpResponse> getPemasukan(@RequestParam Optional<Integer> page,
                                                     @RequestParam Optional<Integer> size) {
        return ResponseEntity.ok(
                HttpResponse.builder()
                        .timeStamp(LocalDateTime.now().toString())
                        .data(Map.of("pemasukan", pemasukanService.getPemasukan(page.orElse(0), size.orElse(10))))
                        .message("Pemasukan retrieved")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build()
        );
    }

    @PutMapping("/update")
    public ResponseEntity<HttpResponse> updatePemasukan(@RequestBody Pemasukan updatedPemasukan) {
        try {
            Pemasukan existingPemasukan = pemasukanService.getPemasukanByKeterangan(updatedPemasukan.getKeterangan());

            if (existingPemasukan != null) {
                // Lakukan pembaruan data

                existingPemasukan.setKeterangan(updatedPemasukan.getKeterangan());
                existingPemasukan.setJumlah(updatedPemasukan.getJumlah());


                // Panggil metode service untuk menyimpan perubahan
                pemasukanService.updatePemasukan(existingPemasukan);

                return ResponseEntity.ok(
                        HttpResponse.builder()
                                .timeStamp(LocalDateTime.now().toString())
                                .data(Map.of("pemasukan", existingPemasukan))
                                .message("Pemasukan updated")
                                .status(HttpStatus.OK)
                                .statusCode(HttpStatus.OK.value())
                                .build()
                );
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(
                                HttpResponse.builder()
                                        .timeStamp(LocalDateTime.now().toString())
                                        .message("Pemasukan with ID " + updatedPemasukan.getKeterangan() + " not found")
                                        .status(HttpStatus.NOT_FOUND)
                                        .statusCode(HttpStatus.NOT_FOUND.value())
                                        .build()
                        );
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(
                            HttpResponse.builder()
                                    .timeStamp(LocalDateTime.now().toString())
                                    .message("Internal Server Error")
                                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                                    .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                                    .build()
                    );
        }
    }


    @DeleteMapping("/delete/{keterangan}")
    public ResponseEntity<HttpResponse> deletePemasukan(@PathVariable String keterangan) {
        try {
            Pemasukan existingPemasukan = pemasukanService.getPemasukanByKeterangan(keterangan);

            if (existingPemasukan != null) {
                pemasukanService.deletePemasukan(keterangan);

                return ResponseEntity.ok(
                        HttpResponse.builder()
                                .timeStamp(LocalDateTime.now().toString())
                                .data(Map.of("pemasukan", existingPemasukan))
                                .message("Pemasukan deleted")
                                .status(HttpStatus.OK)
                                .statusCode(HttpStatus.OK.value())
                                .build()
                );
            }else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(
                                HttpResponse.builder()
                                        .timeStamp(LocalDateTime.now().toString())
                                        .message("Pemasukan with KETERANGAN " + keterangan + " not found")
                                        .status(HttpStatus.NOT_FOUND)
                                        .statusCode(HttpStatus.NOT_FOUND.value())
                                        .build()
                        );
            }


        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(
                            HttpResponse.builder()
                                    .timeStamp(LocalDateTime.now().toString())
                                    .message("Internal Server Error")
                                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                                    .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                                    .build()
                    );
        }

}

}
