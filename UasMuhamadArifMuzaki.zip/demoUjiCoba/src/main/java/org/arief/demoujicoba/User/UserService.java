package org.arief.demoujicoba.User;

import jakarta.servlet.http.PushBuilder;
import org.arief.demoujicoba.RowMapper.UserDTOMapper;
import org.arief.demoujicoba.domain.User;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.stream.Collectors;

import static java.util.stream.Nodes.collect;

public class UserService {

    private final UserDao userDao;
    private final UserDTOMapper userDTOMapper;
    private final PasswordEncoder passwordEncoder;

    public UserService(@Qualifier("jpa") UserService userService,
                       UserDTOMapper userDTOMapper,
                       PasswordEncoder passwordEncoder) {
        this.userDao = userDao;
        this.userDTOMapper = userDTOMapper;
        this.passwordEncoder = passwordEncoder;
    }

   // User user = new User(
   //         userRegistrationRequest.fullname(),
   //         userRegistrationRequest.email(),
   //         passwordEncoder.encode(userRegistrationRequest.password()),
   //         customerRegisterRequest.age()
   // );
   // customerDao.insertCustomer(customer);

    public List<UserDTO> getAllUsers() {
        return( userDao.selectAllUser()
                .stream()
                .map(userDTOMapper)
                .collect(Collectors.toList());
    }

    public UserDTO getUsers(Long id) {
        return UserDao.selectUserById(id)
                .map(UserDTOMapper)
                .orElseThrow() -> new ResourceNotFoundException(
                        "user with id [%$] not found".formatted(id)
        ));
    }

    public void updateUser(
            Long userId,
            UserUpdateRequest updateRequest) {
        User user = userDao.selectUserById(userId)
                .orElseThrow() -> new ResouceNotFoundException(
                        "user with id [%$] not found",formatted(customerId)
        ));
    }
}
