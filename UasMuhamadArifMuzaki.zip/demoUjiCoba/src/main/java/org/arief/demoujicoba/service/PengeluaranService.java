package org.arief.demoujicoba.service;


import org.arief.demoujicoba.domain.Pengeluaran;
import org.springframework.data.domain.Page;

public interface PengeluaranService {
    Pengeluaran createPengeluaran(Pengeluaran pengeluaran);

    Page<Pengeluaran> getPengeluaran (int page, int size);

    Pengeluaran updatePengeluaran(Pengeluaran pengeluaran);

    Pengeluaran getPengeluaranByKeterangan(String keterangan);
}
