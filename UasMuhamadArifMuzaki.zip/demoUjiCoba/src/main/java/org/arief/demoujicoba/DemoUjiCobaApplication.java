package org.arief.demoujicoba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoUjiCobaApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoUjiCobaApplication.class, args);
    }

}
