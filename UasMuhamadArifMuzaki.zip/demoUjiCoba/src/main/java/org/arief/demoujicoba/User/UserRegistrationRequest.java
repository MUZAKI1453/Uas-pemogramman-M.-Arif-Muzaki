package org.arief.demoujicoba.User;

public record UserRegistrationRequest(
        String fullName,
        String email,
        String password
) {
}
