package org.arief.demoujicoba.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@SuperBuilder
@Entity
@Table(name = "pengeluaran")
public class Pengeluaran {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String keterangan;
    private Double jumlah;
}
