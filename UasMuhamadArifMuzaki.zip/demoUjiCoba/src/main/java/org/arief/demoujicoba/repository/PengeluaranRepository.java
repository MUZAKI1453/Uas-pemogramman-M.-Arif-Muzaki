package org.arief.demoujicoba.repository;


import org.arief.demoujicoba.domain.Pengeluaran;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PengeluaranRepository extends JpaRepository<Pengeluaran, String> {
    Pengeluaran findByKeterangan(String keterangan);
}
