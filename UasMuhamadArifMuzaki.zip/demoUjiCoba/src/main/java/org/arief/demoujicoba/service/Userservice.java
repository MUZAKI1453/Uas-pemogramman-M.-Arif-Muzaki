package org.arief.demoujicoba.service;

import org.arief.demoujicoba.domain.User;

public interface Userservice {
    User createUser(User user);
}
