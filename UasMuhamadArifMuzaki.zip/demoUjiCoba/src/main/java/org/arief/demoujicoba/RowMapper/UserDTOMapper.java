package org.arief.demoujicoba.RowMapper;

import org.arief.demoujicoba.User.UserDTO;
import org.arief.demoujicoba.domain.User;
import org.springframework.security.core.GrantedAuthority;

import java.util.stream.Collectors;

public class UserDTOMapper implements Function<User, UserDTO {
    @Override
    public UserDTO apply(User user) {
        return new UserDTO(
                user.getId(),
                user.getFullName(),
                user.getEmail(),
                user.getPassword(),
                user.getAuthorities()
                        .stream()
                        .map(GrantedAuthority::getAuthority)
                        .collect(Collectors.toList()),
                user.getUsername()
        );
    }
}
