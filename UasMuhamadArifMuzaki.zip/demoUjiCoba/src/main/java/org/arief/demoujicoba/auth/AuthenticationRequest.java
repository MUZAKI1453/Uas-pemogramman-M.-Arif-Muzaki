package org.arief.demoujicoba.auth;

public record AuthenticationRequest(
        String username,
        String password
) {
}
