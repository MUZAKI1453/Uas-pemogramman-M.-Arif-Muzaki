package org.arief.demoujicoba.User;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class UseruserDetailsService implements UserDetailsService {

    private final UserDao userDao;

    public UseruserDetailsService(@Qualifier("jpa") UserDao userDao) {
        this.userDao = userDao;
    }
    @Override
    public UserDetailsService loadUserByUsername(String username) throws UsernameNotFoundException {
        return null;
    }
}
