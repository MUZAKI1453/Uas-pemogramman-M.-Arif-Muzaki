package org.arief.demoujicoba.repository;

import org.arief.demoujicoba.domain.Pemasukan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface PemasukanRepository extends JpaRepository<Pemasukan, String> {
    Pemasukan findByKeterangan(String keterangan);
    void deleteByKeterangan(String keterangan);
}