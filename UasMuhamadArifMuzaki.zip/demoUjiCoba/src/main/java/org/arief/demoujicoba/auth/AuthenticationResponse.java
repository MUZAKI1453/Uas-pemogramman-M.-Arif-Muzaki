package org.arief.demoujicoba.auth;

import org.arief.demoujicoba.User.UserDTO;

public record AuthenticationResponse(UserDTO userDTO) {
}
