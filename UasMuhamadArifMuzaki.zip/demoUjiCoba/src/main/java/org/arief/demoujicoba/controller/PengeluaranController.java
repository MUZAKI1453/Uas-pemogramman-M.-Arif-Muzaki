package org.arief.demoujicoba.controller;

import lombok.AllArgsConstructor;
import org.arief.demoujicoba.domain.HttpResponse;
import org.arief.demoujicoba.domain.Pengeluaran;
import org.arief.demoujicoba.service.PengeluaranService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/pengeluaran")
@AllArgsConstructor
public class PengeluaranController {

    private final PengeluaranService pengeluaranService;

    @PostMapping("create")
    public ResponseEntity<HttpResponse> createPengeluaran(@RequestBody Pengeluaran pengeluaran) {
        return ResponseEntity.created(URI.create(""))
                .body(
                        HttpResponse.builder()
                                .timeStamp(LocalDateTime.now().toString())
                                .data(Map.of("pengeluaran", pengeluaranService.createPengeluaran(pengeluaran)))
                                .message("Pengeluaran created")
                                .status(HttpStatus.CREATED)
                                .statusCode(HttpStatus.CREATED.value())
                                .build()
                );
    }


    @GetMapping("list")
    public ResponseEntity<HttpResponse> getPengeluaran (@RequestParam Optional<Integer> page,
                                                        @RequestParam Optional<Integer> size) {
        return ResponseEntity.ok(
                HttpResponse.builder()
                        .timeStamp(LocalDateTime.now().toString())
                        .data(Map.of("pengeluaran", pengeluaranService.getPengeluaran(page.orElse(0), size.orElse(10))))
                        .message("Pengeluaran retrieved")
                        .status(HttpStatus.OK)
                        .statusCode(HttpStatus.OK.value())
                        .build()
        );
    }

    @PutMapping("/update")
    public ResponseEntity<HttpResponse> updatePengeluaran(@RequestBody Pengeluaran updatedPengeluaran) {
        try {
            Pengeluaran existingPengeluaran = pengeluaranService.getPengeluaranByKeterangan(updatedPengeluaran.getKeterangan());

            if (existingPengeluaran != null) {
                // Lakukan pembaruan data

                existingPengeluaran.setKeterangan(updatedPengeluaran.getKeterangan());
                existingPengeluaran.setJumlah(updatedPengeluaran.getJumlah());


                // Panggil metode service untuk menyimpan perubahan
                pengeluaranService.updatePengeluaran(existingPengeluaran);

                return ResponseEntity.ok(
                        HttpResponse.builder()
                                .timeStamp(LocalDateTime.now().toString())
                                .data(Map.of("pengeluaran", existingPengeluaran))
                                .message("Pengeluaran updated")
                                .status(HttpStatus.OK)
                                .statusCode(HttpStatus.OK.value())
                                .build()
                );
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(
                                HttpResponse.builder()
                                        .timeStamp(LocalDateTime.now().toString())
                                        .message("Pengeluaran with ID " + updatedPengeluaran.getKeterangan() + " not found")
                                        .status(HttpStatus.NOT_FOUND)
                                        .statusCode(HttpStatus.NOT_FOUND.value())
                                        .build()
                        );
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(
                            HttpResponse.builder()
                                    .timeStamp(LocalDateTime.now().toString())
                                    .message("Internal Server Error")
                                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                                    .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                                    .build()
                    );
        }
    }
}
