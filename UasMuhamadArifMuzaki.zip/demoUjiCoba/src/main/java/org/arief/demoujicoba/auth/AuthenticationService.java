package org.arief.demoujicoba.auth;

import org.arief.demoujicoba.RowMapper.UserDTOMapper;
import org.arief.demoujicoba.User.UserDTO;
import org.arief.demoujicoba.domain.User;
import org.arief.demoujicoba.jwt.JWTUtil;
import org.hibernate.Session;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

public class AuthenticationService {

    private final AuthenticationManager authenticationManager;
    private final UserDTOMapper userDTOMapper;
    private final JWTUtil jwtUtil;

    public AuthenticationService(AuthenticationManager authenticationManager,
                                 UserDTOMapper userDTOMapper,
                                 JWTUtil jwtUtil) {
        this.authenticationManager = authenticationManager;
        this.userDTOMapper = userDTOMapper;
        this.jwtUtil = jwtUtil;
    }

    public AuthenticationResponse login(AuthenticationRequest request, Session authentication) {
        Authentication authenticate = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.username(),
                        request.password()
                )
        );
        User principal = (User) authentication.getPrincipal();
        UserDTO userDTO = UserDTOMapper.apply(principal);
        jwtUtil.issueToken(userDTO.username(), userDTO.roles())

    }
}
