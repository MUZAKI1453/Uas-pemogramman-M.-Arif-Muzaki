package org.arief.demoujicoba.service.impl;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.arief.demoujicoba.domain.Pengeluaran;
import org.arief.demoujicoba.repository.PengeluaranRepository;
import org.arief.demoujicoba.service.PengeluaranService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
@Transactional
public class PengeluaranServiceImpl implements PengeluaranService {

    private final PengeluaranRepository pengeluaranRepository;
    @Override
    public Pengeluaran createPengeluaran(Pengeluaran pengeluaran) {
        return pengeluaranRepository.save(pengeluaran);
    }

    @Override
    public Page<Pengeluaran> getPengeluaran(int page, int size) {
        return pengeluaranRepository.findAll(PageRequest.of(page, size));
    }

    @Override
    public Pengeluaran updatePengeluaran(Pengeluaran pengeluaran) {
        return pengeluaranRepository.save(pengeluaran);
    }

    @Override
    public Pengeluaran getPengeluaranByKeterangan(String keterangan) {
        return pengeluaranRepository.findByKeterangan(keterangan);
    }
}