package org.arief.demoujicoba.service.impl;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.arief.demoujicoba.domain.User;
import org.arief.demoujicoba.repository.UserRepository;
import org.arief.demoujicoba.service.Userservice;
import org.springframework.stereotype.Service;

@Service
@Transactional
@RequiredArgsConstructor
public class UserServiceImpl implements Userservice {

    private final UserRepository userRepository;
    @Override
    public User createUser(User user) {

        if (userRepository.findByEmail(user.getEmail()) == null) {
            return userRepository.save(user);
        } else {
            throw new RuntimeException("Email sudah digunakan");
        }

    }
}
