package org.arief.demoujicoba.User;

import java.util.List;

public record UserDTO(
        Long id,
        String fullname,
        String email,
        List<String> roles,
        String password
) {
}
