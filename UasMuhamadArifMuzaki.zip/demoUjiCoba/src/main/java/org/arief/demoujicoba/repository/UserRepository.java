package org.arief.demoujicoba.repository;

import org.arief.demoujicoba.domain.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.Optional;

public interface UserRepository
        extends CrudRepository<User, Long>, PagingAndSortingRepository<User, Long> {

    User findByEmail (String email);
    boolean existsUserByEmail(String email);
    boolean existsUsersById(Long id);
    Optional<User> findUsersByEmail(String email);
}
