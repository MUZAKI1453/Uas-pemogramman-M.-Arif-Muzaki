package org.arief.demoujicoba.User;

import org.arief.demoujicoba.domain.User;

import java.util.List;
import java.util.Optional;

public class UserDao {
    List<User> selectAllUser();
    Optional<User> selectUserById(Long id);
    void insertUser(User user);
    boolean existPersonWithEmail(String email);
    boolean existPersonWithId(Long userId);
    void deleteUserById(Long userId);
    void updateUser(User update);
    Optional<User> selectUserByEmail(String email);
}
