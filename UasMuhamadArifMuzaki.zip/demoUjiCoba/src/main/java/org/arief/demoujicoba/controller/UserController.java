package org.arief.demoujicoba.controller;

import lombok.AllArgsConstructor;
import org.arief.demoujicoba.User.UserDTO;
import org.arief.demoujicoba.User.UserRegistrationRequest;
import org.arief.demoujicoba.User.UserService;
import org.arief.demoujicoba.domain.HttpResponse;
import org.arief.demoujicoba.domain.User;
import org.arief.demoujicoba.jwt.JWTUtil;
import org.arief.demoujicoba.service.Userservice;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/user")
@AllArgsConstructor
public class UserController {

    private final Userservice userService;
    private final JWTUtil jwtUtil;

    public UserController(UserService userService,
                          JWTUtil jwtUtil) {
        this.userService = userService;
        this.jwtUtil = jwtUtil;
    }

    @GetMapping
    public List<UserDTO> getUser() {
        return userService.getAllUsers();
    }

    @GetMapping("{userId}")
    public UserDTO getUser(
            @PathVariable("userId") Long userId) {
        return userService.getUsers(userId);
    }


    @PostMapping("create")
    public ResponseEntity<HttpResponse> createUser(@RequestBody User user) {
        return ResponseEntity.created(URI.create(""))
                .body(
                        HttpResponse.builder()
                                .timeStamp(LocalDateTime.now().toString())
                                .data(Map.of("user", userService.createUser(user)))
                                .message("User created")
                                .status(HttpStatus.CREATED)
                                .statusCode(HttpStatus.CREATED.value())
                                .build()
                );
    }

    @PostMapping
    public ResponseEntity<?> registerUser(
            @RequestBody UserRegistrationRequest request) {
        Userservice.addCustomer(request);
        String jwtToken = jwtUtil.issueToken(request.email(), "ROLE_USER");
        return ResponseEntity.ok()
                .header(HttpHeaders.AUTHORIZATION, jwtToken)
                .build();
    }

}

