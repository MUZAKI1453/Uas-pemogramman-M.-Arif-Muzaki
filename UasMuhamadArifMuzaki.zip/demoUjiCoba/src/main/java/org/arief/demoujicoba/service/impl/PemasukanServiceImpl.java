package org.arief.demoujicoba.service.impl;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.arief.demoujicoba.domain.Pemasukan;
import org.arief.demoujicoba.repository.PemasukanRepository;
import org.arief.demoujicoba.service.PemasukanService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Transactional
public class PemasukanServiceImpl implements PemasukanService {

    private final PemasukanRepository pemasukanRepository;
    @Override
    public Pemasukan createPemasukan(Pemasukan pemasukan) {
        return pemasukanRepository.save(pemasukan);
    }

    @Override
    public Page<Pemasukan> getPemasukan(int page, int size) {
        return pemasukanRepository.findAll(PageRequest.of(page, size));
    }

    @Override
    public void updatePemasukan(Pemasukan pemasukan) {
        pemasukanRepository.save(pemasukan);
    }

    @Override
    public Pemasukan getPemasukanByKeterangan(String keterangan) {
        return pemasukanRepository.findByKeterangan(keterangan);
    }

    @Override
    public void deletePemasukan(String keterangan) {
        pemasukanRepository.deleteByKeterangan(keterangan);
    }



}
