package org.arief.demoujicoba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoUjiCobaApplicationTests {

    @Test
    void contextLoads() {
    }

}
